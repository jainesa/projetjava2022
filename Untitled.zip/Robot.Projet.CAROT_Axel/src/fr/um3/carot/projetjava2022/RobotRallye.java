package fr.um3.carot.projetjava2022;

public class RobotRallye {
	
	/*idées :
	 * permettre aux users de choisir leur persos
	 * choisir le niveau de difficultée de la map avec au choix plusieurs map
	 * poser des drapeaux sur les map 
	 * chaqeu joueur spone à un endroit définit
	 * chaque joueur à trois points de vie 
	 * distribution aléatoire des cartes (9 par joueurs)
	 * 7 types de cartes :
	 * avance (1 (530) , 2 (700), 3 (820)
	 * droite (400) et gauche (290)
	 * demi tour (10)
	 * recule 1 (460)
	 * les points pour chaque carte indiquent quand l'ordre 
	 */
/*coucou test jaina*/	
}
