package fr.um3.carot.projetjava2022;

public class Test {

}
